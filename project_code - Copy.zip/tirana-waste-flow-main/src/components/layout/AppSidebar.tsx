import { Link, useRouterState } from "@tanstack/react-router";
import {
  LayoutDashboard, Trash2, Bell, Route as RouteIcon, Truck, CalendarDays,
  MessageSquareWarning, Recycle, BarChart3, Users, Leaf,
} from "lucide-react";
import {
  Sidebar, SidebarContent, SidebarGroup, SidebarGroupContent, SidebarGroupLabel,
  SidebarHeader, SidebarMenu, SidebarMenuButton, SidebarMenuItem, useSidebar,
} from "@/components/ui/sidebar";

const operations = [
  { title: "Dashboard", url: "/", icon: LayoutDashboard },
  { title: "Bin Monitoring", url: "/bins", icon: Trash2 },
  { title: "Alerts", url: "/alerts", icon: Bell },
  { title: "Route Optimization", url: "/routes", icon: RouteIcon },
  { title: "Fleet Management", url: "/fleet", icon: Truck },
  { title: "Scheduling", url: "/schedule", icon: CalendarDays },
];

const community = [
  { title: "Citizen Reports", url: "/reports", icon: MessageSquareWarning },
  { title: "Recycling", url: "/recycling", icon: Recycle },
];

const admin = [
  { title: "Analytics", url: "/analytics", icon: BarChart3 },
  { title: "Users & Roles", url: "/users", icon: Users },
];

export function AppSidebar() {
  const { state } = useSidebar();
  const collapsed = state === "collapsed";
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const isActive = (url: string) => (url === "/" ? pathname === "/" : pathname.startsWith(url));

  const renderGroup = (label: string, items: typeof operations) => (
    <SidebarGroup>
      {!collapsed && <SidebarGroupLabel className="text-sidebar-foreground/60 uppercase tracking-wider text-[10px]">{label}</SidebarGroupLabel>}
      <SidebarGroupContent>
        <SidebarMenu>
          {items.map((item) => (
            <SidebarMenuItem key={item.title}>
              <SidebarMenuButton asChild isActive={isActive(item.url)} tooltip={item.title}>
                <Link to={item.url} className="flex items-center gap-3">
                  <item.icon className="h-4 w-4 shrink-0" />
                  {!collapsed && <span className="text-sm">{item.title}</span>}
                </Link>
              </SidebarMenuButton>
            </SidebarMenuItem>
          ))}
        </SidebarMenu>
      </SidebarGroupContent>
    </SidebarGroup>
  );

  return (
    <Sidebar collapsible="icon" className="border-r-0">
      <SidebarHeader className="border-b border-sidebar-border">
        <div className="flex items-center gap-3 px-2 py-3">
          <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-sidebar-primary text-sidebar-primary-foreground shadow-md">
            <Leaf className="h-5 w-5" />
          </div>
          {!collapsed && (
            <div className="flex flex-col leading-tight">
              <span className="font-semibold text-sidebar-foreground text-sm">ECO Tirana</span>
              <span className="text-[10px] text-sidebar-foreground/60 uppercase tracking-wider">Smart Waste</span>
            </div>
          )}
        </div>
      </SidebarHeader>
      <SidebarContent>
        {renderGroup("Operations", operations)}
        {renderGroup("Community", community)}
        {renderGroup("Administration", admin)}
      </SidebarContent>
    </Sidebar>
  );
}
