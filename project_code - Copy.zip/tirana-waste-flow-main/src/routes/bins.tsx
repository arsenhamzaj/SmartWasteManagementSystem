import { createFileRoute } from "@tanstack/react-router";
import { PageHeader } from "@/components/layout/PageHeader";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Trash2, MapPin, Search } from "lucide-react";
import { useMemo, useState } from "react";
import { BINS, ZONES, type Bin } from "@/lib/mock-data";
import { toast } from "sonner";

export const Route = createFileRoute("/bins")({ component: BinsPage });

const statusColor: Record<string, string> = {
  normal: "bg-success",
  almost_full: "bg-warning",
  full: "bg-destructive",
  damaged: "bg-muted-foreground",
};
const statusLabel: Record<string, string> = {
  normal: "Normal", almost_full: "Almost Full", full: "Full", damaged: "Damaged",
};

function BinsPage() {
  const [query, setQuery] = useState("");
  const [zone, setZone] = useState("all");
  const [status, setStatus] = useState("all");
  const [type, setType] = useState("all");
  const [selected, setSelected] = useState<Bin | null>(null);

  const filtered = useMemo(() => BINS.filter(b =>
    (zone === "all" || b.zone === zone) &&
    (status === "all" || b.status === status) &&
    (type === "all" || b.type === type) &&
    (b.code.toLowerCase().includes(query.toLowerCase()) || b.street.toLowerCase().includes(query.toLowerCase()))
  ), [query, zone, status, type]);

  const counts = {
    normal: BINS.filter(b => b.status === "normal").length,
    almost_full: BINS.filter(b => b.status === "almost_full").length,
    full: BINS.filter(b => b.status === "full").length,
    damaged: BINS.filter(b => b.status === "damaged").length,
  };

  return (
    <>
      <PageHeader title="Bin Monitoring" description="Live status of waste bins across Tirana" actions={
        <Button onClick={() => toast.success("Bin data refreshed", { description: "Simulated real-time sync complete" })}>Refresh data</Button>
      } />

      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-5">
        {(["normal","almost_full","full","damaged"] as const).map(s => (
          <Card key={s}>
            <CardContent className="pt-5 flex items-center gap-3">
              <div className={`h-3 w-3 rounded-full ${statusColor[s]}`} />
              <div>
                <p className="text-xs text-muted-foreground">{statusLabel[s]}</p>
                <p className="text-2xl font-semibold">{counts[s]}</p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card className="mb-5">
        <CardContent className="pt-5 flex flex-wrap gap-3">
          <div className="relative flex-1 min-w-[200px]">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input value={query} onChange={e => setQuery(e.target.value)} placeholder="Search bin code or street..." className="pl-9" />
          </div>
          <Select value={zone} onValueChange={setZone}>
            <SelectTrigger className="w-[200px]"><SelectValue placeholder="Zone" /></SelectTrigger>
            <SelectContent><SelectItem value="all">All zones</SelectItem>{ZONES.map(z => <SelectItem key={z} value={z}>{z}</SelectItem>)}</SelectContent>
          </Select>
          <Select value={status} onValueChange={setStatus}>
            <SelectTrigger className="w-[160px]"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All status</SelectItem>
              <SelectItem value="normal">Normal</SelectItem>
              <SelectItem value="almost_full">Almost full</SelectItem>
              <SelectItem value="full">Full</SelectItem>
              <SelectItem value="damaged">Damaged</SelectItem>
            </SelectContent>
          </Select>
          <Select value={type} onValueChange={setType}>
            <SelectTrigger className="w-[150px]"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All types</SelectItem>
              <SelectItem value="general">General</SelectItem>
              <SelectItem value="recycling">Recycling</SelectItem>
              <SelectItem value="organic">Organic</SelectItem>
              <SelectItem value="glass">Glass</SelectItem>
            </SelectContent>
          </Select>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle>Tirana zone map</CardTitle>
            <CardDescription>{filtered.length} bins shown · click to inspect</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="relative h-[480px] rounded-lg bg-gradient-to-br from-accent/5 to-primary/5 border overflow-hidden">
              {/* Stylized map grid */}
              <svg className="absolute inset-0 h-full w-full opacity-20" xmlns="http://www.w3.org/2000/svg">
                <defs>
                  <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
                    <path d="M 40 0 L 0 0 0 40" fill="none" stroke="currentColor" strokeWidth="0.5" />
                  </pattern>
                </defs>
                <rect width="100%" height="100%" fill="url(#grid)" />
              </svg>
              <div className="absolute top-4 left-4 px-3 py-1.5 bg-card border rounded-md text-xs font-medium flex items-center gap-2">
                <MapPin className="h-3 w-3" /> Tirana, AL
              </div>
              {filtered.map((b) => {
                const x = ((b.lng - 19.77) / 0.1) * 100;
                const y = ((41.36 - b.lat) / 0.08) * 100;
                return (
                  <button
                    key={b.id}
                    onClick={() => setSelected(b)}
                    style={{ left: `${Math.max(2, Math.min(96, x))}%`, top: `${Math.max(2, Math.min(94, y))}%` }}
                    className={`absolute h-3 w-3 rounded-full ${statusColor[b.status]} ring-2 ring-background hover:scale-150 transition-transform ${b.status === "full" ? "animate-pulse" : ""}`}
                    title={b.code}
                  />
                );
              })}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Bin list</CardTitle>
            <CardDescription>Sorted by fill level</CardDescription>
          </CardHeader>
          <CardContent className="space-y-2 max-h-[480px] overflow-auto pr-1">
            {[...filtered].sort((a,b) => b.fill - a.fill).slice(0, 30).map(b => (
              <button key={b.id} onClick={() => setSelected(b)} className="w-full text-left p-3 rounded-lg border hover:bg-muted/50 transition">
                <div className="flex justify-between items-center mb-1">
                  <div className="flex items-center gap-2">
                    <Trash2 className="h-4 w-4 text-muted-foreground" />
                    <span className="font-medium text-sm">{b.code}</span>
                  </div>
                  <Badge variant="outline" className="text-[10px] capitalize">{b.type}</Badge>
                </div>
                <p className="text-xs text-muted-foreground truncate mb-2">{b.street}</p>
                <div className="flex items-center gap-2">
                  <Progress value={b.fill} className="h-1.5 flex-1" />
                  <span className="text-xs font-medium w-9 text-right">{b.fill}%</span>
                </div>
              </button>
            ))}
          </CardContent>
        </Card>
      </div>

      <Dialog open={!!selected} onOpenChange={(o) => !o && setSelected(null)}>
        <DialogContent>
          {selected && (
            <>
              <DialogHeader>
                <DialogTitle className="flex items-center gap-2"><Trash2 className="h-5 w-5" />{selected.code}</DialogTitle>
                <DialogDescription>{selected.street} · {selected.zone}</DialogDescription>
              </DialogHeader>
              <div className="space-y-4 py-2">
                <div className="grid grid-cols-2 gap-3 text-sm">
                  <div><p className="text-xs text-muted-foreground">Status</p><Badge className={`${statusColor[selected.status]} text-white mt-1`}>{statusLabel[selected.status]}</Badge></div>
                  <div><p className="text-xs text-muted-foreground">Type</p><p className="capitalize font-medium">{selected.type}</p></div>
                  <div><p className="text-xs text-muted-foreground">Capacity</p><p className="font-medium">{selected.capacity} L</p></div>
                  <div><p className="text-xs text-muted-foreground">Last collected</p><p className="font-medium">{selected.lastCollected}</p></div>
                </div>
                <div>
                  <div className="flex justify-between text-sm mb-1.5"><span>Fill level</span><span className="font-medium">{selected.fill}%</span></div>
                  <Progress value={selected.fill} className="h-3" />
                </div>
                <div className="text-xs text-muted-foreground">Coordinates: {selected.lat.toFixed(5)}, {selected.lng.toFixed(5)}</div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => { toast.info("Report created", { description: `Maintenance ticket for ${selected.code}` }); setSelected(null); }}>Report issue</Button>
                <Button onClick={() => { toast.success("Pickup scheduled", { description: `${selected.code} added to next route` }); setSelected(null); }}>Schedule pickup</Button>
              </DialogFooter>
            </>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}
