import { createFileRoute } from "@tanstack/react-router";
import { PageHeader } from "@/components/layout/PageHeader";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Bell, CheckCircle2, AlertTriangle, ArrowUpCircle } from "lucide-react";
import { useState } from "react";
import { ALERTS, type AlertItem, type AlertStatus } from "@/lib/mock-data";
import { toast } from "sonner";

export const Route = createFileRoute("/alerts")({ component: AlertsPage });

const priorityStyle = (p: string) =>
  p === "critical" ? "bg-destructive text-destructive-foreground" :
  p === "high" ? "bg-warning text-warning-foreground" :
  p === "medium" ? "bg-info text-info-foreground" :
  "bg-muted text-muted-foreground";

const statusStyle = (s: string) =>
  s === "resolved" ? "bg-success/15 text-success border-success/30" :
  s === "escalated" ? "bg-destructive/15 text-destructive border-destructive/30" :
  s === "acknowledged" ? "bg-info/15 text-info border-info/30" :
  "bg-warning/15 text-warning border-warning/30";

function AlertsPage() {
  const [alerts, setAlerts] = useState<AlertItem[]>(ALERTS);
  const [filter, setFilter] = useState<string>("all");

  const update = (id: string, status: AlertStatus, msg: string) => {
    setAlerts(prev => prev.map(a => a.id === id ? { ...a, status } : a));
    toast.success(msg);
  };

  const filtered = filter === "all" ? alerts : alerts.filter(a => a.status === filter);

  const counts = {
    open: alerts.filter(a => a.status === "open").length,
    acknowledged: alerts.filter(a => a.status === "acknowledged").length,
    escalated: alerts.filter(a => a.status === "escalated").length,
    resolved: alerts.filter(a => a.status === "resolved").length,
  };

  return (
    <>
      <PageHeader title="Alerts & Escalations" description="Triage and resolve issues across the network" />

      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-5">
        <Card><CardContent className="pt-5"><p className="text-xs text-muted-foreground">Open</p><p className="text-2xl font-semibold text-warning">{counts.open}</p></CardContent></Card>
        <Card><CardContent className="pt-5"><p className="text-xs text-muted-foreground">Acknowledged</p><p className="text-2xl font-semibold text-info">{counts.acknowledged}</p></CardContent></Card>
        <Card><CardContent className="pt-5"><p className="text-xs text-muted-foreground">Escalated</p><p className="text-2xl font-semibold text-destructive">{counts.escalated}</p></CardContent></Card>
        <Card><CardContent className="pt-5"><p className="text-xs text-muted-foreground">Resolved</p><p className="text-2xl font-semibold text-success">{counts.resolved}</p></CardContent></Card>
      </div>

      <Tabs value={filter} onValueChange={setFilter}>
        <TabsList>
          <TabsTrigger value="all">All</TabsTrigger>
          <TabsTrigger value="open">Open</TabsTrigger>
          <TabsTrigger value="acknowledged">Acknowledged</TabsTrigger>
          <TabsTrigger value="escalated">Escalated</TabsTrigger>
          <TabsTrigger value="resolved">Resolved</TabsTrigger>
        </TabsList>
        <TabsContent value={filter} className="mt-4 space-y-3">
          {filtered.map(a => (
            <Card key={a.id} className="hover:shadow-md transition">
              <CardContent className="pt-5">
                <div className="flex flex-col md:flex-row md:items-center gap-4">
                  <div className={`h-10 w-10 rounded-lg flex items-center justify-center shrink-0 ${a.priority === "critical" ? "bg-destructive/15 text-destructive" : "bg-warning/15 text-warning"}`}>
                    <AlertTriangle className="h-5 w-5" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex flex-wrap items-center gap-2 mb-1">
                      <h3 className="font-semibold">{a.title}</h3>
                      <Badge className={`${priorityStyle(a.priority)} text-[10px] uppercase`}>{a.priority}</Badge>
                      <Badge variant="outline" className={`${statusStyle(a.status)} text-[10px] uppercase`}>{a.status.replace("_", " ")}</Badge>
                    </div>
                    <p className="text-sm text-muted-foreground">{a.description}</p>
                    <p className="text-xs text-muted-foreground mt-1">{a.zone} · {a.source} · {a.createdAt}</p>
                  </div>
                  <div className="flex gap-2 flex-wrap">
                    {a.status === "open" && <Button size="sm" variant="outline" onClick={() => update(a.id, "acknowledged", "Alert acknowledged")}>Acknowledge</Button>}
                    {a.status !== "resolved" && a.status !== "escalated" && <Button size="sm" variant="outline" onClick={() => update(a.id, "escalated", "Alert escalated to manager")}><ArrowUpCircle className="h-3.5 w-3.5 mr-1" />Escalate</Button>}
                    {a.status !== "resolved" && <Button size="sm" onClick={() => update(a.id, "resolved", "Alert resolved")}><CheckCircle2 className="h-3.5 w-3.5 mr-1" />Resolve</Button>}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
          {filtered.length === 0 && (
            <Card><CardContent className="py-12 text-center text-muted-foreground"><Bell className="h-8 w-8 mx-auto mb-2 opacity-50" />No alerts in this view</CardContent></Card>
          )}
        </TabsContent>
      </Tabs>
    </>
  );
}
