import { createFileRoute } from "@tanstack/react-router";
import { PageHeader } from "@/components/layout/PageHeader";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Route as RouteIcon, Truck, MapPin, Clock, Trash2, CheckCircle2, Circle, Sparkles } from "lucide-react";
import { useState } from "react";
import { ROUTES, type CollectionRoute } from "@/lib/mock-data";
import { toast } from "sonner";

export const Route = createFileRoute("/routes")({ component: RoutesPage });

const statusStyle = (s: string) =>
  s === "completed" ? "bg-success text-success-foreground" :
  s === "in_progress" ? "bg-info text-info-foreground" :
  s === "delayed" ? "bg-destructive text-destructive-foreground" :
  "bg-muted text-muted-foreground";

function RoutesPage() {
  const [routes, setRoutes] = useState<CollectionRoute[]>(ROUTES);
  const [selected, setSelected] = useState<CollectionRoute | null>(null);
  const [generating, setGenerating] = useState(false);

  const generate = () => {
    setGenerating(true);
    toast.info("Optimizing routes...", { description: "Prioritizing full bins" });
    setTimeout(() => {
      const newRoute: CollectionRoute = {
        id: `r${routes.length + 1}`,
        code: `R-${20 + routes.length}`,
        truck: "AA-104-EC",
        driver: "Genti Shehu",
        zones: ["Njësia 5 - Blloku", "Njësia 1 - Qendër"],
        bins: 22,
        distance: 16.8,
        duration: 85,
        status: "planned",
        progress: 0,
        stops: [
          { name: "Blloku Qendër (priority)", done: false },
          { name: "Sheshi Skënderbej", done: false },
          { name: "Rruga Myslym Shyri", done: false },
        ],
      };
      setRoutes([newRoute, ...routes]);
      setGenerating(false);
      toast.success("New optimized route generated", { description: `${newRoute.code} · ${newRoute.bins} bins · ${newRoute.distance} km` });
    }, 1400);
  };

  return (
    <>
      <PageHeader title="Route Optimization" description="AI-optimized collection routes prioritizing full bins" actions={
        <Button onClick={generate} disabled={generating}><Sparkles className="h-4 w-4 mr-1.5" />{generating ? "Generating..." : "Generate Optimized Route"}</Button>
      } />

      <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-4">
        {routes.map(r => (
          <Card key={r.id} className="hover:shadow-lg transition cursor-pointer" onClick={() => setSelected(r)}>
            <CardHeader>
              <div className="flex items-start justify-between">
                <div>
                  <CardTitle className="flex items-center gap-2"><RouteIcon className="h-5 w-5 text-primary" />{r.code}</CardTitle>
                  <CardDescription>{r.zones.join(" · ")}</CardDescription>
                </div>
                <Badge className={`${statusStyle(r.status)} text-[10px] uppercase`}>{r.status.replace("_", " ")}</Badge>
              </div>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="grid grid-cols-2 gap-3 text-sm">
                <div className="flex items-center gap-2"><Truck className="h-3.5 w-3.5 text-muted-foreground" /><span className="truncate">{r.truck}</span></div>
                <div className="flex items-center gap-2"><Trash2 className="h-3.5 w-3.5 text-muted-foreground" /><span>{r.bins} bins</span></div>
                <div className="flex items-center gap-2"><MapPin className="h-3.5 w-3.5 text-muted-foreground" /><span>{r.distance} km</span></div>
                <div className="flex items-center gap-2"><Clock className="h-3.5 w-3.5 text-muted-foreground" /><span>{r.duration} min</span></div>
              </div>
              <div>
                <div className="flex justify-between text-xs mb-1.5"><span className="text-muted-foreground">Progress</span><span className="font-medium">{r.progress}%</span></div>
                <Progress value={r.progress} className="h-1.5" />
              </div>
              <div className="text-xs text-muted-foreground border-t pt-2">Driver: <span className="text-foreground font-medium">{r.driver}</span></div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Dialog open={!!selected} onOpenChange={(o) => !o && setSelected(null)}>
        <DialogContent className="max-w-2xl">
          {selected && (
            <>
              <DialogHeader>
                <DialogTitle className="flex items-center gap-2"><RouteIcon className="h-5 w-5" />{selected.code} · Route detail</DialogTitle>
                <DialogDescription>{selected.driver} · {selected.truck}</DialogDescription>
              </DialogHeader>
              <div className="grid grid-cols-4 gap-3 py-2">
                <div><p className="text-xs text-muted-foreground">Bins</p><p className="text-lg font-semibold">{selected.bins}</p></div>
                <div><p className="text-xs text-muted-foreground">Distance</p><p className="text-lg font-semibold">{selected.distance} km</p></div>
                <div><p className="text-xs text-muted-foreground">Duration</p><p className="text-lg font-semibold">{selected.duration} min</p></div>
                <div><p className="text-xs text-muted-foreground">Status</p><Badge className={`${statusStyle(selected.status)} mt-0.5`}>{selected.status.replace("_"," ")}</Badge></div>
              </div>
              <div>
                <h4 className="text-sm font-semibold mb-3">Step-by-step stops</h4>
                <ol className="relative border-l-2 border-border ml-3 space-y-3">
                  {selected.stops.map((s, i) => (
                    <li key={i} className="ml-5 flex items-center gap-2">
                      <span className={`absolute -left-[11px] h-5 w-5 rounded-full flex items-center justify-center ${s.done ? "bg-success text-success-foreground" : "bg-muted border"}`}>
                        {s.done ? <CheckCircle2 className="h-3.5 w-3.5" /> : <Circle className="h-3 w-3 text-muted-foreground" />}
                      </span>
                      <span className={`text-sm ${s.done ? "text-muted-foreground line-through" : ""}`}>{s.name}</span>
                    </li>
                  ))}
                </ol>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}
