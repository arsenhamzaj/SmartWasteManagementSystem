import { createFileRoute } from "@tanstack/react-router";
import { PageHeader } from "@/components/layout/PageHeader";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import {
  Trash2, Truck, AlertCircle, MessageSquareWarning, Recycle, CheckCircle2,
  TrendingUp, TrendingDown, ArrowRight,
} from "lucide-react";
import {
  ResponsiveContainer, AreaChart, Area, XAxis, YAxis, Tooltip, CartesianGrid,
  LineChart, Line, BarChart, Bar, Legend,
} from "recharts";
import { ALERTS, wasteCollectedTrend, recyclingPerformance, fleetUsage, BINS, TRUCKS } from "@/lib/mock-data";
import { Link } from "@tanstack/react-router";

export const Route = createFileRoute("/")({ component: Dashboard });

const kpis = [
  { label: "Total Bins", value: BINS.length.toString(), icon: Trash2, trend: "+4", up: true, color: "primary" },
  { label: "Full Bins", value: BINS.filter(b => b.status === "full").length.toString(), icon: AlertCircle, trend: "+12%", up: false, color: "destructive" },
  { label: "Active Trucks", value: `${TRUCKS.filter(t => t.status === "on_route").length}/${TRUCKS.length}`, icon: Truck, trend: "On schedule", up: true, color: "info" },
  { label: "Pending Reports", value: "8", icon: MessageSquareWarning, trend: "-3", up: true, color: "warning" },
  { label: "Recycling Rate", value: "54%", icon: Recycle, trend: "+2.4%", up: true, color: "success" },
  { label: "Collections Today", value: "47", icon: CheckCircle2, trend: "of 62 planned", up: true, color: "primary" },
];

function KpiCard({ k }: { k: typeof kpis[number] }) {
  const Icon = k.icon;
  return (
    <Card className="relative overflow-hidden kpi-gradient hover:shadow-md transition-shadow">
      <CardContent className="pt-6">
        <div className="flex items-start justify-between">
          <div>
            <p className="text-xs uppercase tracking-wider text-muted-foreground font-medium">{k.label}</p>
            <p className="text-3xl font-semibold mt-2 tracking-tight">{k.value}</p>
            <p className={`text-xs mt-2 flex items-center gap-1 ${k.up ? "text-success" : "text-destructive"}`}>
              {k.up ? <TrendingUp className="h-3 w-3" /> : <TrendingDown className="h-3 w-3" />}
              {k.trend}
            </p>
          </div>
          <div className="h-10 w-10 rounded-lg bg-primary/10 text-primary flex items-center justify-center">
            <Icon className="h-5 w-5" />
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

const priorityStyle = (p: string) =>
  p === "critical" ? "bg-destructive text-destructive-foreground" :
  p === "high" ? "bg-warning text-warning-foreground" :
  p === "medium" ? "bg-info text-info-foreground" :
  "bg-muted text-muted-foreground";

function Dashboard() {
  const fillByZone = BINS.reduce<Record<string, number[]>>((acc, b) => {
    (acc[b.zone] ??= []).push(b.fill); return acc;
  }, {});
  const zoneFill = Object.entries(fillByZone).slice(0, 5).map(([z, arr]) => ({
    zone: z.split(" - ")[1] ?? z, fill: Math.round(arr.reduce((a, b) => a + b, 0) / arr.length),
  }));

  return (
    <>
      <PageHeader
        title="Operations Dashboard"
        description="Real-time overview of waste collection across Tirana"
        actions={
          <>
            <Badge variant="outline" className="gap-1.5 py-1.5"><span className="h-2 w-2 rounded-full bg-success animate-pulse" />Live · {new Date().toLocaleTimeString()}</Badge>
            <Button variant="outline" size="sm">Export</Button>
            <Button size="sm">New collection</Button>
          </>
        }
      />

      <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-6 gap-4 mb-6">
        {kpis.map((k) => <KpiCard key={k.label} k={k} />)}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 mb-6">
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle>Waste collected (tonnes)</CardTitle>
            <CardDescription>Last 7 days by waste type</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={280}>
              <AreaChart data={wasteCollectedTrend}>
                <defs>
                  <linearGradient id="g1" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="var(--chart-1)" stopOpacity={0.6}/><stop offset="100%" stopColor="var(--chart-1)" stopOpacity={0}/></linearGradient>
                  <linearGradient id="g2" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="var(--chart-2)" stopOpacity={0.6}/><stop offset="100%" stopColor="var(--chart-2)" stopOpacity={0}/></linearGradient>
                  <linearGradient id="g3" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="var(--chart-3)" stopOpacity={0.6}/><stop offset="100%" stopColor="var(--chart-3)" stopOpacity={0}/></linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                <XAxis dataKey="day" stroke="var(--muted-foreground)" fontSize={12} />
                <YAxis stroke="var(--muted-foreground)" fontSize={12} />
                <Tooltip contentStyle={{ background: "var(--card)", border: "1px solid var(--border)", borderRadius: 8 }} />
                <Legend />
                <Area type="monotone" dataKey="general" stroke="var(--chart-1)" fill="url(#g1)" />
                <Area type="monotone" dataKey="recycling" stroke="var(--chart-2)" fill="url(#g2)" />
                <Area type="monotone" dataKey="organic" stroke="var(--chart-3)" fill="url(#g3)" />
              </AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Recycling rate</CardTitle>
            <CardDescription>Monthly trend %</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={280}>
              <LineChart data={recyclingPerformance}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                <XAxis dataKey="month" stroke="var(--muted-foreground)" fontSize={12} />
                <YAxis stroke="var(--muted-foreground)" fontSize={12} />
                <Tooltip contentStyle={{ background: "var(--card)", border: "1px solid var(--border)", borderRadius: 8 }} />
                <Line type="monotone" dataKey="rate" stroke="var(--chart-1)" strokeWidth={3} dot={{ r: 3 }} />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <Card>
          <CardHeader>
            <CardTitle>Top zones · avg fill level</CardTitle>
            <CardDescription>Worst-performing zones today</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {zoneFill.map((z) => (
              <div key={z.zone}>
                <div className="flex justify-between text-sm mb-1.5">
                  <span className="font-medium">{z.zone}</span>
                  <span className="text-muted-foreground">{z.fill}%</span>
                </div>
                <Progress value={z.fill} className="h-2" />
              </div>
            ))}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Fleet usage</CardTitle>
            <CardDescription>Trucks active by hour today</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={220}>
              <BarChart data={fleetUsage}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                <XAxis dataKey="hour" stroke="var(--muted-foreground)" fontSize={11} />
                <YAxis stroke="var(--muted-foreground)" fontSize={11} />
                <Tooltip contentStyle={{ background: "var(--card)", border: "1px solid var(--border)", borderRadius: 8 }} />
                <Bar dataKey="trucks" fill="var(--chart-2)" radius={[6,6,0,0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex-row items-center justify-between">
            <div>
              <CardTitle>Recent alerts</CardTitle>
              <CardDescription>Urgent issues requiring action</CardDescription>
            </div>
            <Link to="/alerts"><Button variant="ghost" size="sm" className="gap-1">All <ArrowRight className="h-3 w-3" /></Button></Link>
          </CardHeader>
          <CardContent className="space-y-3">
            {ALERTS.slice(0, 4).map((a) => (
              <div key={a.id} className="flex items-start gap-3 p-3 rounded-lg border bg-muted/30 hover:bg-muted/50 transition">
                <div className={`h-2 w-2 rounded-full mt-2 ${a.priority === "critical" ? "bg-destructive animate-pulse" : a.priority === "high" ? "bg-warning" : "bg-info"}`} />
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium truncate">{a.title}</p>
                  <p className="text-xs text-muted-foreground truncate">{a.zone} · {a.createdAt}</p>
                </div>
                <Badge className={`${priorityStyle(a.priority)} text-[10px] uppercase`}>{a.priority}</Badge>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>
    </>
  );
}
