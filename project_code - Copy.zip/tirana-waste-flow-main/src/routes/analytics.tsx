import { createFileRoute } from "@tanstack/react-router";
import { PageHeader } from "@/components/layout/PageHeader";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Download, FileText, TrendingUp, TrendingDown, Fuel, Leaf, MapPin } from "lucide-react";
import {
  ResponsiveContainer, AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, Legend,
  BarChart, Bar, LineChart, Line,
} from "recharts";
import { wasteCollectedTrend, recyclingPerformance, zoneComparison, fleetUsage, ZONES } from "@/lib/mock-data";
import { toast } from "sonner";

export const Route = createFileRoute("/analytics")({ component: AnalyticsPage });

function AnalyticsPage() {
  return (
    <>
      <PageHeader title="Analytics & Reports" description="Performance insights across the smart waste network" actions={
        <>
          <Button variant="outline" onClick={() => toast.success("CSV exported")}><Download className="h-4 w-4 mr-1.5" />CSV</Button>
          <Button onClick={() => toast.success("PDF report generated")}><FileText className="h-4 w-4 mr-1.5" />PDF report</Button>
        </>
      } />

      <Card className="mb-5">
        <CardContent className="pt-5 flex flex-wrap gap-3">
          <Select defaultValue="30d"><SelectTrigger className="w-[160px]"><SelectValue /></SelectTrigger><SelectContent>
            <SelectItem value="7d">Last 7 days</SelectItem><SelectItem value="30d">Last 30 days</SelectItem>
            <SelectItem value="90d">Last 90 days</SelectItem><SelectItem value="365d">Last year</SelectItem>
          </SelectContent></Select>
          <Select defaultValue="all"><SelectTrigger className="w-[200px]"><SelectValue /></SelectTrigger><SelectContent>
            <SelectItem value="all">All zones</SelectItem>{ZONES.map(z => <SelectItem key={z} value={z}>{z}</SelectItem>)}
          </SelectContent></Select>
          <Select defaultValue="all"><SelectTrigger className="w-[160px]"><SelectValue /></SelectTrigger><SelectContent>
            <SelectItem value="all">All trucks</SelectItem><SelectItem value="t1">AA-100-TR</SelectItem><SelectItem value="t2">AA-103-AL</SelectItem>
          </SelectContent></Select>
          <Select defaultValue="all"><SelectTrigger className="w-[160px]"><SelectValue /></SelectTrigger><SelectContent>
            <SelectItem value="all">All waste types</SelectItem>
            <SelectItem value="general">General</SelectItem><SelectItem value="recycling">Recycling</SelectItem>
            <SelectItem value="organic">Organic</SelectItem><SelectItem value="glass">Glass</SelectItem>
          </SelectContent></Select>
        </CardContent>
      </Card>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-5">
        {[
          { l: "Total collected", v: "1,284 t", trend: "+8.2%", up: true, icon: Leaf },
          { l: "Fuel saved", v: "4,210 L", trend: "+12%", up: true, icon: Fuel },
          { l: "CO₂ reduction", v: "11.3 t", trend: "+9%", up: true, icon: Leaf },
          { l: "Avg bin fill", v: "62%", trend: "-3%", up: false, icon: MapPin },
        ].map(k => {
          const Icon = k.icon;
          return (
            <Card key={k.l}><CardContent className="pt-5"><div className="flex items-start justify-between"><div><p className="text-xs text-muted-foreground">{k.l}</p><p className="text-2xl font-semibold mt-1">{k.v}</p><p className={`text-xs mt-1 flex items-center gap-1 ${k.up ? "text-success" : "text-warning"}`}>{k.up ? <TrendingUp className="h-3 w-3" /> : <TrendingDown className="h-3 w-3" />}{k.trend}</p></div><div className="h-9 w-9 rounded-lg bg-primary/10 text-primary flex items-center justify-center"><Icon className="h-5 w-5" /></div></div></CardContent></Card>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 mb-4">
        <Card className="lg:col-span-2">
          <CardHeader><CardTitle>Waste collected trend</CardTitle><CardDescription>By waste type, daily</CardDescription></CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <AreaChart data={wasteCollectedTrend}>
                <defs>
                  <linearGradient id="a1" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="var(--chart-1)" stopOpacity={0.5}/><stop offset="100%" stopColor="var(--chart-1)" stopOpacity={0}/></linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                <XAxis dataKey="day" stroke="var(--muted-foreground)" fontSize={12} />
                <YAxis stroke="var(--muted-foreground)" fontSize={12} />
                <Tooltip contentStyle={{ background: "var(--card)", border: "1px solid var(--border)", borderRadius: 8 }} />
                <Legend />
                <Area type="monotone" dataKey="general" stackId="1" stroke="var(--chart-1)" fill="url(#a1)" />
                <Area type="monotone" dataKey="recycling" stackId="1" stroke="var(--chart-2)" fill="var(--chart-2)" fillOpacity={0.3} />
                <Area type="monotone" dataKey="organic" stackId="1" stroke="var(--chart-3)" fill="var(--chart-3)" fillOpacity={0.3} />
              </AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
        <Card>
          <CardHeader><CardTitle>Insights</CardTitle><CardDescription>Auto-generated</CardDescription></CardHeader>
          <CardContent className="space-y-3 text-sm">
            <div className="p-3 rounded-lg border bg-warning/5"><Badge variant="outline" className="mb-1.5">Hotspot</Badge><p><strong>Blloku</strong> has the highest bin fill rate (84% avg). Consider extra pickup.</p></div>
            <div className="p-3 rounded-lg border bg-success/5"><Badge variant="outline" className="mb-1.5">Sustainability</Badge><p>Route optimization saved <strong>4,210L</strong> of fuel this period.</p></div>
            <div className="p-3 rounded-lg border bg-info/5"><Badge variant="outline" className="mb-1.5">Trend</Badge><p>Recycling rate up <strong>+2.4%</strong> — Don Bosko leads improvement.</p></div>
            <div className="p-3 rounded-lg border"><Badge variant="outline" className="mb-1.5">Fleet</Badge><p>Average truck utilization is <strong>68%</strong>, peak at 10:00.</p></div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Card>
          <CardHeader><CardTitle>Most problematic zones</CardTitle><CardDescription>By collection volume</CardDescription></CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={280}>
              <BarChart data={zoneComparison} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                <XAxis type="number" stroke="var(--muted-foreground)" fontSize={12} />
                <YAxis dataKey="zone" type="category" stroke="var(--muted-foreground)" fontSize={11} width={80} />
                <Tooltip contentStyle={{ background: "var(--card)", border: "1px solid var(--border)", borderRadius: 8 }} />
                <Bar dataKey="collected" fill="var(--chart-2)" radius={[0,6,6,0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
        <Card>
          <CardHeader><CardTitle>Recycling performance</CardTitle><CardDescription>Monthly rate</CardDescription></CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={280}>
              <LineChart data={recyclingPerformance}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                <XAxis dataKey="month" stroke="var(--muted-foreground)" fontSize={12} />
                <YAxis stroke="var(--muted-foreground)" fontSize={12} />
                <Tooltip contentStyle={{ background: "var(--card)", border: "1px solid var(--border)", borderRadius: 8 }} />
                <Line type="monotone" dataKey="rate" stroke="var(--chart-1)" strokeWidth={3} />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>
    </>
  );
}
