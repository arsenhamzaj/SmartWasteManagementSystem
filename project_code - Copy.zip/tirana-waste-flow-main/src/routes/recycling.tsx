import { createFileRoute } from "@tanstack/react-router";
import { PageHeader } from "@/components/layout/PageHeader";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Recycle, Leaf, AlertTriangle, TrendingUp } from "lucide-react";
import {
  ResponsiveContainer, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip,
  PieChart, Pie, Cell, BarChart, Bar, Legend,
} from "recharts";
import { recyclingPerformance, wasteDistribution, zoneComparison, BINS } from "@/lib/mock-data";

export const Route = createFileRoute("/recycling")({ component: RecyclingPage });

const COLORS = ["var(--chart-1)", "var(--chart-2)", "var(--chart-3)", "var(--chart-4)"];

function RecyclingPage() {
  const recyclingBins = BINS.filter(b => b.type === "recycling");
  const contaminated = 4; // mock
  return (
    <>
      <PageHeader title="Recycling Management" description="Sustainability metrics and recycling stream monitoring" />

      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-5">
        <Card><CardContent className="pt-5"><div className="flex items-start justify-between"><div><p className="text-xs text-muted-foreground">Recycling Rate</p><p className="text-2xl font-semibold">54%</p><p className="text-xs text-success mt-1 flex items-center gap-1"><TrendingUp className="h-3 w-3" />+2.4% vs last month</p></div><div className="h-9 w-9 rounded-lg bg-primary/10 text-primary flex items-center justify-center"><Recycle className="h-5 w-5" /></div></div></CardContent></Card>
        <Card><CardContent className="pt-5"><div className="flex items-start justify-between"><div><p className="text-xs text-muted-foreground">Recycling Bins</p><p className="text-2xl font-semibold">{recyclingBins.length}</p><p className="text-xs text-muted-foreground mt-1">Across Tirana</p></div><div className="h-9 w-9 rounded-lg bg-success/15 text-success flex items-center justify-center"><Leaf className="h-5 w-5" /></div></div></CardContent></Card>
        <Card><CardContent className="pt-5"><div className="flex items-start justify-between"><div><p className="text-xs text-muted-foreground">Contamination Alerts</p><p className="text-2xl font-semibold">{contaminated}</p><p className="text-xs text-warning mt-1">Requires action</p></div><div className="h-9 w-9 rounded-lg bg-warning/15 text-warning flex items-center justify-center"><AlertTriangle className="h-5 w-5" /></div></div></CardContent></Card>
        <Card><CardContent className="pt-5"><div className="flex items-start justify-between"><div><p className="text-xs text-muted-foreground">CO₂ Saved (est)</p><p className="text-2xl font-semibold">128t</p><p className="text-xs text-success mt-1">This year</p></div><div className="h-9 w-9 rounded-lg bg-info/15 text-info flex items-center justify-center"><Leaf className="h-5 w-5" /></div></div></CardContent></Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 mb-4">
        <Card className="lg:col-span-2">
          <CardHeader><CardTitle>Recycling rate trend</CardTitle><CardDescription>Last 12 months %</CardDescription></CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={280}>
              <LineChart data={recyclingPerformance}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                <XAxis dataKey="month" stroke="var(--muted-foreground)" fontSize={12} />
                <YAxis stroke="var(--muted-foreground)" fontSize={12} />
                <Tooltip contentStyle={{ background: "var(--card)", border: "1px solid var(--border)", borderRadius: 8 }} />
                <Line type="monotone" dataKey="rate" stroke="var(--chart-1)" strokeWidth={3} />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
        <Card>
          <CardHeader><CardTitle>Waste type distribution</CardTitle><CardDescription>Citywide composition</CardDescription></CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={280}>
              <PieChart>
                <Pie data={wasteDistribution} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={90} label>
                  {wasteDistribution.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                </Pie>
                <Tooltip contentStyle={{ background: "var(--card)", border: "1px solid var(--border)", borderRadius: 8 }} />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Card>
          <CardHeader><CardTitle>Zone comparison</CardTitle><CardDescription>Collected vs recycled (tonnes)</CardDescription></CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={280}>
              <BarChart data={zoneComparison}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                <XAxis dataKey="zone" stroke="var(--muted-foreground)" fontSize={10} angle={-20} textAnchor="end" height={50} />
                <YAxis stroke="var(--muted-foreground)" fontSize={12} />
                <Tooltip contentStyle={{ background: "var(--card)", border: "1px solid var(--border)", borderRadius: 8 }} />
                <Legend />
                <Bar dataKey="collected" fill="var(--chart-2)" radius={[6,6,0,0]} />
                <Bar dataKey="recycled" fill="var(--chart-1)" radius={[6,6,0,0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
        <Card>
          <CardHeader><CardTitle>Contamination alerts</CardTitle><CardDescription>Streams requiring inspection</CardDescription></CardHeader>
          <CardContent className="space-y-3">
            {[
              { zone: "Blloku", type: "Plastic stream", level: 78 },
              { zone: "Don Bosko", type: "Paper stream", level: 42 },
              { zone: "Selitë", type: "Glass stream", level: 65 },
              { zone: "Qendër", type: "Organic stream", level: 31 },
            ].map(c => (
              <div key={c.zone + c.type} className="p-3 rounded-lg border">
                <div className="flex justify-between items-center mb-2">
                  <div><p className="font-medium text-sm">{c.zone}</p><p className="text-xs text-muted-foreground">{c.type}</p></div>
                  <Badge variant={c.level > 60 ? "destructive" : "secondary"}>{c.level}%</Badge>
                </div>
                <Progress value={c.level} className="h-1.5" />
              </div>
            ))}
          </CardContent>
        </Card>
      </div>
    </>
  );
}
