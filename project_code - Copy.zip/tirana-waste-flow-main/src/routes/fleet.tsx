import { createFileRoute } from "@tanstack/react-router";
import { PageHeader } from "@/components/layout/PageHeader";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Truck as TruckIcon, Fuel, Wrench, User } from "lucide-react";
import { useState } from "react";
import { TRUCKS, type Truck } from "@/lib/mock-data";
import { toast } from "sonner";

export const Route = createFileRoute("/fleet")({ component: FleetPage });

const statusStyle = (s: string) =>
  s === "available" ? "bg-success text-success-foreground" :
  s === "on_route" ? "bg-info text-info-foreground" :
  s === "maintenance" ? "bg-warning text-warning-foreground" :
  "bg-muted text-muted-foreground";

function FleetPage() {
  const [selected, setSelected] = useState<Truck | null>(null);

  const counts = {
    available: TRUCKS.filter(t => t.status === "available").length,
    on_route: TRUCKS.filter(t => t.status === "on_route").length,
    maintenance: TRUCKS.filter(t => t.status === "maintenance").length,
    offline: TRUCKS.filter(t => t.status === "offline").length,
  };

  return (
    <>
      <PageHeader title="Fleet Management" description="Monitor and manage ECO Tirana's collection trucks" actions={<Button>Add truck</Button>} />

      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-5">
        <Card><CardContent className="pt-5"><p className="text-xs text-muted-foreground">Available</p><p className="text-2xl font-semibold text-success">{counts.available}</p></CardContent></Card>
        <Card><CardContent className="pt-5"><p className="text-xs text-muted-foreground">On Route</p><p className="text-2xl font-semibold text-info">{counts.on_route}</p></CardContent></Card>
        <Card><CardContent className="pt-5"><p className="text-xs text-muted-foreground">Maintenance</p><p className="text-2xl font-semibold text-warning">{counts.maintenance}</p></CardContent></Card>
        <Card><CardContent className="pt-5"><p className="text-xs text-muted-foreground">Offline</p><p className="text-2xl font-semibold text-muted-foreground">{counts.offline}</p></CardContent></Card>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
        {TRUCKS.map(t => (
          <Card key={t.id} className="hover:shadow-lg transition cursor-pointer" onClick={() => setSelected(t)}>
            <CardHeader>
              <div className="flex items-start justify-between">
                <div>
                  <CardTitle className="flex items-center gap-2"><TruckIcon className="h-5 w-5 text-primary" />{t.plate}</CardTitle>
                  <CardDescription>{t.model}</CardDescription>
                </div>
                <Badge className={`${statusStyle(t.status)} text-[10px] uppercase`}>{t.status.replace("_"," ")}</Badge>
              </div>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center gap-2 text-sm"><User className="h-3.5 w-3.5 text-muted-foreground" />{t.driver}</div>
              <div>
                <div className="flex justify-between text-xs mb-1"><span className="text-muted-foreground">Capacity</span><span className="font-medium">{t.capacity}%</span></div>
                <Progress value={t.capacity} className="h-1.5" />
              </div>
              <div>
                <div className="flex justify-between text-xs mb-1"><span className="text-muted-foreground flex items-center gap-1"><Fuel className="h-3 w-3" />Fuel</span><span className="font-medium">{t.fuel}%</span></div>
                <Progress value={t.fuel} className="h-1.5" />
              </div>
              <div className="flex items-center justify-between text-xs border-t pt-2">
                <span className="text-muted-foreground flex items-center gap-1"><Wrench className="h-3 w-3" />Service in {t.nextService}</span>
                <span className="text-muted-foreground">{t.km.toLocaleString()} km</span>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Dialog open={!!selected} onOpenChange={(o) => !o && setSelected(null)}>
        <DialogContent>
          {selected && (
            <>
              <DialogHeader>
                <DialogTitle className="flex items-center gap-2"><TruckIcon className="h-5 w-5" />{selected.plate}</DialogTitle>
                <DialogDescription>{selected.model} · {selected.zone}</DialogDescription>
              </DialogHeader>
              <div className="grid grid-cols-2 gap-3 py-2 text-sm">
                <div><p className="text-xs text-muted-foreground">Driver</p><p className="font-medium">{selected.driver}</p></div>
                <div><p className="text-xs text-muted-foreground">Status</p><Badge className={statusStyle(selected.status)}>{selected.status.replace("_"," ")}</Badge></div>
                <div><p className="text-xs text-muted-foreground">Capacity</p><p className="font-medium">{selected.capacity}%</p></div>
                <div><p className="text-xs text-muted-foreground">Fuel</p><p className="font-medium">{selected.fuel}%</p></div>
                <div><p className="text-xs text-muted-foreground">Odometer</p><p className="font-medium">{selected.km.toLocaleString()} km</p></div>
                <div><p className="text-xs text-muted-foreground">Next service</p><p className="font-medium">{selected.nextService}</p></div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => { toast.info("Maintenance scheduled"); setSelected(null); }}>Schedule maintenance</Button>
                <Button onClick={() => { toast.success("Driver reassigned"); setSelected(null); }}>Assign driver</Button>
              </DialogFooter>
            </>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}
