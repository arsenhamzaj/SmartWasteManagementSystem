import { createFileRoute } from "@tanstack/react-router";
import { PageHeader } from "@/components/layout/PageHeader";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from "@/components/ui/table";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, Pencil, Trash2, Shield, CheckCircle2, X } from "lucide-react";
import { useState } from "react";
import { USERS } from "@/lib/mock-data";
import { toast } from "sonner";

export const Route = createFileRoute("/users")({ component: UsersPage });

const ROLES = ["Admin", "Waste Management Manager", "Truck Driver", "Field Operator", "Citizen", "IT System Administrator"];

const permissionsMatrix: Record<string, string[]> = {
  Admin: ["Full access", "Manage users", "Manage roles", "View analytics", "Export reports"],
  "Waste Management Manager": ["View dashboard", "Manage routes", "Manage schedules", "Assign drivers", "Resolve alerts"],
  "Truck Driver": ["View assigned route", "Update collection status", "Report bin issues"],
  "Field Operator": ["View assigned reports", "Update report status", "Report bin damage"],
  Citizen: ["Submit reports", "View own reports", "View recycling info"],
  "IT System Administrator": ["System config", "Manage integrations", "View logs", "Manage users"],
};

function UsersPage() {
  const [users, setUsers] = useState(USERS);
  const [open, setOpen] = useState(false);
  const [draft, setDraft] = useState({ name: "", email: "", role: "Truck Driver" });
  const [activeRole, setActiveRole] = useState("Admin");

  const add = () => {
    setUsers([{ id: `u${users.length + 1}`, ...draft, status: "active" }, ...users]);
    setOpen(false);
    setDraft({ name: "", email: "", role: "Truck Driver" });
    toast.success("User created");
  };
  const remove = (id: string) => { setUsers(users.filter(u => u.id !== id)); toast.success("User removed"); };

  return (
    <>
      <PageHeader title="Users & Roles" description="Manage platform access and role permissions" actions={
        <Button onClick={() => setOpen(true)}><Plus className="h-4 w-4 mr-1.5" />Add user</Button>
      } />

      <Tabs defaultValue="users">
        <TabsList>
          <TabsTrigger value="users">Users</TabsTrigger>
          <TabsTrigger value="permissions">Roles & Permissions</TabsTrigger>
        </TabsList>
        <TabsContent value="users" className="mt-4">
          <Card><CardContent className="pt-5 overflow-auto">
            <Table>
              <TableHeader><TableRow><TableHead>User</TableHead><TableHead>Email</TableHead><TableHead>Role</TableHead><TableHead>Status</TableHead><TableHead></TableHead></TableRow></TableHeader>
              <TableBody>
                {users.map(u => (
                  <TableRow key={u.id}>
                    <TableCell>
                      <div className="flex items-center gap-3">
                        <Avatar className="h-8 w-8"><AvatarFallback className="bg-primary/15 text-primary text-xs">{u.name.split(" ").map(n => n[0]).join("")}</AvatarFallback></Avatar>
                        <span className="font-medium">{u.name}</span>
                      </div>
                    </TableCell>
                    <TableCell className="text-muted-foreground">{u.email}</TableCell>
                    <TableCell><Badge variant="outline">{u.role}</Badge></TableCell>
                    <TableCell>{u.status === "active" ? <Badge className="bg-success text-success-foreground gap-1"><CheckCircle2 className="h-3 w-3" />Active</Badge> : <Badge variant="secondary" className="gap-1"><X className="h-3 w-3" />Inactive</Badge>}</TableCell>
                    <TableCell className="text-right">
                      <Button variant="ghost" size="icon" onClick={() => toast.info("Edit user")}><Pencil className="h-3.5 w-3.5" /></Button>
                      <Button variant="ghost" size="icon" onClick={() => remove(u.id)}><Trash2 className="h-3.5 w-3.5 text-destructive" /></Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent></Card>
        </TabsContent>
        <TabsContent value="permissions" className="mt-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card>
              <CardHeader><CardTitle className="text-base">Roles</CardTitle><CardDescription>Select to view permissions</CardDescription></CardHeader>
              <CardContent className="space-y-1">
                {ROLES.map(r => (
                  <button key={r} onClick={() => setActiveRole(r)} className={`w-full text-left px-3 py-2 rounded-md text-sm flex items-center gap-2 transition ${activeRole === r ? "bg-primary text-primary-foreground" : "hover:bg-muted"}`}>
                    <Shield className="h-3.5 w-3.5" />{r}
                  </button>
                ))}
              </CardContent>
            </Card>
            <Card className="md:col-span-2">
              <CardHeader><CardTitle className="text-base">{activeRole} permissions</CardTitle><CardDescription>What this role can do</CardDescription></CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  {permissionsMatrix[activeRole].map(p => (
                    <li key={p} className="flex items-center gap-3 p-2.5 rounded-md border bg-muted/30">
                      <CheckCircle2 className="h-4 w-4 text-success" /><span className="text-sm">{p}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>Add user</DialogTitle></DialogHeader>
          <div className="space-y-3 py-2">
            <div className="space-y-1.5"><Label>Name</Label><Input value={draft.name} onChange={e => setDraft({ ...draft, name: e.target.value })} /></div>
            <div className="space-y-1.5"><Label>Email</Label><Input type="email" value={draft.email} onChange={e => setDraft({ ...draft, email: e.target.value })} /></div>
            <div className="space-y-1.5"><Label>Role</Label>
              <Select value={draft.role} onValueChange={v => setDraft({ ...draft, role: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{ROLES.map(r => <SelectItem key={r} value={r}>{r}</SelectItem>)}</SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter><Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button><Button onClick={add}>Create</Button></DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
