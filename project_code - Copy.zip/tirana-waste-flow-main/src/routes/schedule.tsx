import { createFileRoute } from "@tanstack/react-router";
import { Fragment } from "react";
import { PageHeader } from "@/components/layout/PageHeader";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, CalendarDays } from "lucide-react";
import { useState } from "react";
import { schedule as initialSchedule, ZONES, DAYS, TIME_SLOTS, TRUCKS } from "@/lib/mock-data";
import { toast } from "sonner";

export const Route = createFileRoute("/schedule")({ component: SchedulePage });

const statusStyle = (s: string) =>
  s === "completed" ? "bg-success text-success-foreground" :
  s === "in_progress" ? "bg-info text-info-foreground animate-pulse" :
  "bg-muted text-foreground border";

function SchedulePage() {
  const [items, setItems] = useState(initialSchedule);
  const [open, setOpen] = useState(false);
  const [draft, setDraft] = useState({ day: "Mon", time: "06:00", zone: ZONES[0], truck: TRUCKS[0].plate, driver: TRUCKS[0].driver });

  const itemsAt = (day: string, time: string) => items.filter(i => i.day === day && i.time === time);

  const addItem = () => {
    setItems(prev => [...prev, { id: `s${prev.length + 1}`, ...draft, status: "planned" }]);
    setOpen(false);
    toast.success("Collection scheduled", { description: `${draft.day} ${draft.time} · ${draft.zone}` });
  };

  return (
    <>
      <PageHeader title="Collection Scheduling" description="Weekly collection plan with manual override" actions={
        <Button onClick={() => setOpen(true)}><Plus className="h-4 w-4 mr-1.5" />New schedule</Button>
      } />

      <Card>
        <CardContent className="pt-5 overflow-auto">
          <div className="min-w-[900px] grid gap-2" style={{ gridTemplateColumns: `100px repeat(${DAYS.length}, 1fr)` }}>
            <div />
            {DAYS.map(d => (
              <div key={d} className="text-center text-xs font-semibold uppercase tracking-wider text-muted-foreground py-2 border-b">
                <CalendarDays className="h-3 w-3 inline mr-1" />{d}
              </div>
            ))}
            {TIME_SLOTS.map(time => (
              <Fragment key={`row-${time}`}>
                <div className="text-xs font-medium text-muted-foreground py-3">{time}</div>
                {DAYS.map(day => (
                  <div key={`${day}-${time}`} className="min-h-[80px] border rounded-md p-2 bg-muted/20 hover:bg-muted/40 transition space-y-1.5">
                    {itemsAt(day, time).map(i => (
                      <div key={i.id} className="p-2 rounded bg-card border text-xs space-y-1 cursor-grab hover:shadow-md transition">
                        <div className="flex items-center justify-between gap-1">
                          <span className="font-medium truncate">{i.zone.split(" - ")[1] ?? i.zone}</span>
                          <Badge className={`${statusStyle(i.status)} text-[9px] uppercase shrink-0`}>{i.status.replace("_"," ")}</Badge>
                        </div>
                        <p className="text-muted-foreground truncate">{i.truck} · {i.driver.split(" ")[0]}</p>
                      </div>
                    ))}
                  </div>
                ))}
              </Fragment>
            ))}
          </div>
        </CardContent>
      </Card>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>New scheduled collection</DialogTitle></DialogHeader>
          <div className="space-y-3 py-2">
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label>Day</Label>
                <Select value={draft.day} onValueChange={v => setDraft({ ...draft, day: v })}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent>{DAYS.map(d => <SelectItem key={d} value={d}>{d}</SelectItem>)}</SelectContent></Select>
              </div>
              <div className="space-y-1.5">
                <Label>Time</Label>
                <Select value={draft.time} onValueChange={v => setDraft({ ...draft, time: v })}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent>{TIME_SLOTS.map(t => <SelectItem key={t} value={t}>{t}</SelectItem>)}</SelectContent></Select>
              </div>
            </div>
            <div className="space-y-1.5">
              <Label>Zone</Label>
              <Select value={draft.zone} onValueChange={v => setDraft({ ...draft, zone: v })}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent>{ZONES.map(z => <SelectItem key={z} value={z}>{z}</SelectItem>)}</SelectContent></Select>
            </div>
            <div className="space-y-1.5">
              <Label>Truck & driver</Label>
              <Select value={draft.truck} onValueChange={v => { const t = TRUCKS.find(t => t.plate === v)!; setDraft({ ...draft, truck: v, driver: t.driver }); }}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{TRUCKS.map(t => <SelectItem key={t.id} value={t.plate}>{t.plate} · {t.driver}</SelectItem>)}</SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
            <Button onClick={addItem}>Schedule</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
