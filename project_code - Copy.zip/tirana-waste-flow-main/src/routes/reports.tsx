import { createFileRoute } from "@tanstack/react-router";
import { PageHeader } from "@/components/layout/PageHeader";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from "@/components/ui/table";
import { Plus, ImageIcon, Eye } from "lucide-react";
import { useState } from "react";
import { REPORTS, type CitizenReport, type ReportStatus } from "@/lib/mock-data";
import { toast } from "sonner";

export const Route = createFileRoute("/reports")({ component: ReportsPage });

const statusStyle = (s: string) =>
  s === "resolved" ? "bg-success text-success-foreground" :
  s === "assigned" ? "bg-info text-info-foreground" :
  s === "under_review" ? "bg-warning text-warning-foreground" :
  "bg-muted text-foreground border";

const priorityStyle = (p: string) =>
  p === "critical" ? "bg-destructive text-destructive-foreground" :
  p === "high" ? "bg-warning text-warning-foreground" :
  p === "medium" ? "bg-info text-info-foreground" :
  "bg-muted text-muted-foreground";

function ReportsPage() {
  const [reports, setReports] = useState<CitizenReport[]>(REPORTS);
  const [open, setOpen] = useState(false);
  const [viewing, setViewing] = useState<CitizenReport | null>(null);
  const [draft, setDraft] = useState({ type: "Overflowing bin", location: "", description: "", priority: "medium" as const });

  const submit = () => {
    const newRep: CitizenReport = {
      id: `rep${reports.length + 1}`, citizen: "You", ...draft, status: "submitted", createdAt: "just now",
    };
    setReports([newRep, ...reports]);
    setOpen(false);
    setDraft({ type: "Overflowing bin", location: "", description: "", priority: "medium" });
    toast.success("Report submitted", { description: "ECO Tirana will review shortly" });
  };

  const advance = (id: string, status: ReportStatus, msg: string) => {
    setReports(prev => prev.map(r => r.id === id ? { ...r, status, assignedTo: status === "assigned" ? "Field Op #2" : r.assignedTo } : r));
    toast.success(msg);
  };

  return (
    <>
      <PageHeader title="Citizen Reports" description="Submitted issues from Tirana residents" actions={
        <Button onClick={() => setOpen(true)}><Plus className="h-4 w-4 mr-1.5" />Submit report</Button>
      } />

      <Tabs defaultValue="admin">
        <TabsList>
          <TabsTrigger value="admin">Admin view</TabsTrigger>
          <TabsTrigger value="citizen">Citizen view</TabsTrigger>
        </TabsList>
        <TabsContent value="admin" className="mt-4">
          <Card><CardContent className="pt-5 overflow-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>ID</TableHead><TableHead>Citizen</TableHead><TableHead>Type</TableHead>
                  <TableHead>Location</TableHead><TableHead>Priority</TableHead><TableHead>Status</TableHead>
                  <TableHead>Assigned</TableHead><TableHead>Created</TableHead><TableHead></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {reports.map(r => (
                  <TableRow key={r.id} className="hover:bg-muted/40">
                    <TableCell className="font-mono text-xs">{r.id}</TableCell>
                    <TableCell>{r.citizen}</TableCell>
                    <TableCell>{r.type}</TableCell>
                    <TableCell className="text-muted-foreground">{r.location}</TableCell>
                    <TableCell><Badge className={`${priorityStyle(r.priority)} text-[10px] uppercase`}>{r.priority}</Badge></TableCell>
                    <TableCell><Badge className={`${statusStyle(r.status)} text-[10px] uppercase`}>{r.status.replace("_"," ")}</Badge></TableCell>
                    <TableCell className="text-xs text-muted-foreground">{r.assignedTo ?? "—"}</TableCell>
                    <TableCell className="text-xs text-muted-foreground">{r.createdAt}</TableCell>
                    <TableCell><Button size="sm" variant="ghost" onClick={() => setViewing(r)}><Eye className="h-3.5 w-3.5" /></Button></TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent></Card>
        </TabsContent>
        <TabsContent value="citizen" className="mt-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {reports.filter(r => r.citizen === "You" || r.citizen === "Anila K.").map(r => (
              <Card key={r.id}>
                <CardContent className="pt-5 space-y-2">
                  <div className="flex justify-between"><h4 className="font-semibold">{r.type}</h4><Badge className={statusStyle(r.status)}>{r.status.replace("_"," ")}</Badge></div>
                  <p className="text-sm text-muted-foreground">{r.location}</p>
                  <p className="text-sm">{r.description}</p>
                  <p className="text-xs text-muted-foreground">{r.createdAt}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Submit a report</DialogTitle>
            <DialogDescription>Help ECO Tirana keep the city clean</DialogDescription>
          </DialogHeader>
          <div className="space-y-3 py-2">
            <div className="space-y-1.5"><Label>Issue type</Label>
              <Select value={draft.type} onValueChange={v => setDraft({ ...draft, type: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="Overflowing bin">Overflowing bin</SelectItem>
                  <SelectItem value="Damaged bin">Damaged bin</SelectItem>
                  <SelectItem value="Illegal dumping">Illegal dumping</SelectItem>
                  <SelectItem value="Missed collection">Missed collection</SelectItem>
                  <SelectItem value="Recycling issue">Recycling issue</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5"><Label>Location</Label><Input value={draft.location} onChange={e => setDraft({ ...draft, location: e.target.value })} placeholder="Street, neighbourhood" /></div>
            <div className="space-y-1.5"><Label>Description</Label><Textarea value={draft.description} onChange={e => setDraft({ ...draft, description: e.target.value })} placeholder="Describe the issue..." rows={3} /></div>
            <div className="space-y-1.5"><Label>Priority</Label>
              <Select value={draft.priority} onValueChange={v => setDraft({ ...draft, priority: v as any })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="low">Low</SelectItem><SelectItem value="medium">Medium</SelectItem>
                  <SelectItem value="high">High</SelectItem><SelectItem value="critical">Critical</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5"><Label>Photo</Label>
              <div className="border-2 border-dashed rounded-md p-6 text-center text-sm text-muted-foreground hover:bg-muted/30 cursor-pointer">
                <ImageIcon className="h-6 w-6 mx-auto mb-1.5 opacity-60" />
                Click to upload a photo (mock)
              </div>
            </div>
          </div>
          <DialogFooter><Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button><Button onClick={submit}>Submit report</Button></DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={!!viewing} onOpenChange={(o) => !o && setViewing(null)}>
        <DialogContent>
          {viewing && (
            <>
              <DialogHeader>
                <DialogTitle>{viewing.type}</DialogTitle>
                <DialogDescription>Report {viewing.id} · by {viewing.citizen}</DialogDescription>
              </DialogHeader>
              <div className="space-y-3 py-2">
                <div className="grid grid-cols-2 gap-3 text-sm">
                  <div><p className="text-xs text-muted-foreground">Location</p><p className="font-medium">{viewing.location}</p></div>
                  <div><p className="text-xs text-muted-foreground">Created</p><p className="font-medium">{viewing.createdAt}</p></div>
                  <div><p className="text-xs text-muted-foreground">Priority</p><Badge className={priorityStyle(viewing.priority)}>{viewing.priority}</Badge></div>
                  <div><p className="text-xs text-muted-foreground">Status</p><Badge className={statusStyle(viewing.status)}>{viewing.status.replace("_"," ")}</Badge></div>
                </div>
                <div><p className="text-xs text-muted-foreground mb-1">Description</p><p className="text-sm">{viewing.description}</p></div>
                <div>
                  <p className="text-xs text-muted-foreground mb-2">Timeline</p>
                  <ol className="relative border-l-2 border-border ml-2 space-y-2 pl-4 text-sm">
                    <li><span className="absolute -left-[7px] h-3 w-3 rounded-full bg-primary" />Submitted by citizen</li>
                    {viewing.status !== "submitted" && <li><span className="absolute -left-[7px] h-3 w-3 rounded-full bg-info" />Under review by manager</li>}
                    {(viewing.status === "assigned" || viewing.status === "resolved") && <li><span className="absolute -left-[7px] h-3 w-3 rounded-full bg-info" />Assigned to {viewing.assignedTo ?? "field operator"}</li>}
                    {viewing.status === "resolved" && <li><span className="absolute -left-[7px] h-3 w-3 rounded-full bg-success" />Resolved</li>}
                  </ol>
                </div>
              </div>
              <DialogFooter className="flex-wrap gap-2">
                {viewing.status === "submitted" && <Button variant="outline" onClick={() => { advance(viewing.id, "under_review", "Moved to review"); setViewing(null); }}>Mark under review</Button>}
                {viewing.status !== "assigned" && viewing.status !== "resolved" && <Button variant="outline" onClick={() => { advance(viewing.id, "assigned", "Assigned to field operator"); setViewing(null); }}>Assign field operator</Button>}
                {viewing.status !== "resolved" && <Button onClick={() => { advance(viewing.id, "resolved", "Report resolved"); setViewing(null); }}>Resolve</Button>}
              </DialogFooter>
            </>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}
