// Realistic mock data for ECO Tirana Smart Waste Management
export const ZONES = [
  "Njësia 1 - Qendër",
  "Njësia 2 - Selitë",
  "Njësia 3 - Laprakë",
  "Njësia 4 - Don Bosko",
  "Njësia 5 - Blloku",
  "Njësia 6 - Kombinat",
  "Njësia 7 - Tufinë",
  "Njësia 8 - Kashar",
  "Njësia 9 - Yzberisht",
  "Njësia 10 - Farkë",
  "Njësia 11 - Kamëz",
];

export type BinStatus = "normal" | "almost_full" | "full" | "damaged";
export type WasteType = "general" | "recycling" | "organic" | "glass";

export interface Bin {
  id: string;
  code: string;
  zone: string;
  street: string;
  type: WasteType;
  fill: number; // 0-100
  status: BinStatus;
  lastCollected: string;
  capacity: number; // liters
  lat: number;
  lng: number;
}

const streets = [
  "Rruga e Durrësit", "Bulevardi Dëshmorët e Kombit", "Rruga e Kavajës",
  "Rruga e Elbasanit", "Bulevardi Zogu I", "Rruga Myslym Shyri",
  "Rruga Sami Frashëri", "Rruga Abdyl Frashëri", "Rruga Ibrahim Rugova",
  "Rruga Bajram Curri", "Rruga e Barrikadave", "Rruga Murat Toptani",
];

const wasteTypes: WasteType[] = ["general", "recycling", "organic", "glass"];

function statusFromFill(fill: number, damaged: boolean): BinStatus {
  if (damaged) return "damaged";
  if (fill >= 90) return "full";
  if (fill >= 70) return "almost_full";
  return "normal";
}

export const BINS: Bin[] = Array.from({ length: 64 }).map((_, i) => {
  const damaged = i % 23 === 0;
  const fill = damaged ? 0 : Math.floor(Math.random() * 100);
  const zone = ZONES[i % ZONES.length];
  return {
    id: `bin-${i + 1}`,
    code: `TR-${String(i + 1).padStart(4, "0")}`,
    zone,
    street: streets[i % streets.length],
    type: wasteTypes[i % wasteTypes.length],
    fill,
    status: statusFromFill(fill, damaged),
    lastCollected: `${Math.floor(Math.random() * 48)}h ago`,
    capacity: [240, 360, 660, 1100][i % 4],
    lat: 41.32 + (Math.random() - 0.5) * 0.08,
    lng: 19.81 + (Math.random() - 0.5) * 0.1,
  };
});

export type AlertPriority = "low" | "medium" | "high" | "critical";
export type AlertStatus = "open" | "acknowledged" | "resolved" | "escalated";
export interface AlertItem {
  id: string;
  title: string;
  description: string;
  priority: AlertPriority;
  status: AlertStatus;
  zone: string;
  source: "bin" | "truck" | "route" | "recycling" | "citizen";
  createdAt: string;
}

export const ALERTS: AlertItem[] = [
  { id: "a1", title: "Bin TR-0042 overflowing", description: "Fill level above 95% for 4 hours", priority: "critical", status: "open", zone: ZONES[4], source: "bin", createdAt: "12 min ago" },
  { id: "a2", title: "Truck T-07 engine warning", description: "Diagnostic code P0420 reported", priority: "high", status: "acknowledged", zone: ZONES[2], source: "truck", createdAt: "1 h ago" },
  { id: "a3", title: "Missed collection on Route R-12", description: "Driver reported access blocked", priority: "high", status: "open", zone: ZONES[6], source: "route", createdAt: "2 h ago" },
  { id: "a4", title: "Recycling contamination — Blloku", description: "Glass found in plastic stream", priority: "medium", status: "open", zone: ZONES[4], source: "recycling", createdAt: "3 h ago" },
  { id: "a5", title: "Damaged bin reported by citizen", description: "Lid broken, vermin risk", priority: "medium", status: "escalated", zone: ZONES[0], source: "citizen", createdAt: "5 h ago" },
  { id: "a6", title: "Low fuel — Truck T-03", description: "Below 15% capacity", priority: "low", status: "resolved", zone: ZONES[1], source: "truck", createdAt: "8 h ago" },
  { id: "a7", title: "Bin TR-0019 inactive", description: "No signal for 24h", priority: "medium", status: "open", zone: ZONES[7], source: "bin", createdAt: "1 d ago" },
];

export type TruckStatus = "available" | "on_route" | "maintenance" | "offline";
export interface Truck {
  id: string;
  plate: string;
  model: string;
  driver: string;
  status: TruckStatus;
  capacity: number; // %
  fuel: number; // %
  zone: string;
  nextService: string;
  km: number;
}

const drivers = ["Arben Hoxha", "Bledar Kola", "Erion Meta", "Genti Shehu", "Klodian Bregu", "Petrit Dervishi", "Rezart Mema", "Saimir Doçi"];

export const TRUCKS: Truck[] = Array.from({ length: 12 }).map((_, i) => {
  const statuses: TruckStatus[] = ["available", "on_route", "on_route", "maintenance", "offline", "available"];
  return {
    id: `truck-${i + 1}`,
    plate: `AA-${String(100 + i)}-${["TR", "AL", "EC"][i % 3]}`,
    model: ["Iveco Daily", "MAN TGM", "Mercedes Econic", "Volvo FE"][i % 4],
    driver: drivers[i % drivers.length],
    status: statuses[i % statuses.length],
    capacity: Math.floor(Math.random() * 100),
    fuel: 20 + Math.floor(Math.random() * 80),
    zone: ZONES[i % ZONES.length],
    nextService: `${Math.floor(Math.random() * 30) + 1} days`,
    km: 40000 + Math.floor(Math.random() * 120000),
  };
});

export type RouteStatus = "planned" | "in_progress" | "completed" | "delayed";
export interface CollectionRoute {
  id: string;
  code: string;
  truck: string;
  driver: string;
  zones: string[];
  bins: number;
  distance: number;
  duration: number; // minutes
  status: RouteStatus;
  progress: number;
  stops: { name: string; done: boolean }[];
}

export const ROUTES: CollectionRoute[] = [
  { id: "r1", code: "R-12", truck: "AA-100-TR", driver: drivers[0], zones: [ZONES[0], ZONES[4]], bins: 24, distance: 18.4, duration: 95, status: "in_progress", progress: 62, stops: [
    { name: "Sheshi Skënderbej", done: true }, { name: "Rruga Myslym Shyri", done: true }, { name: "Blloku Qendër", done: true }, { name: "Pazari i Ri", done: false }, { name: "Stacioni i Trenit", done: false },
  ]},
  { id: "r2", code: "R-07", truck: "AA-103-AL", driver: drivers[1], zones: [ZONES[2], ZONES[3]], bins: 31, distance: 22.1, duration: 110, status: "planned", progress: 0, stops: [
    { name: "Laprakë Veri", done: false }, { name: "Don Bosko", done: false }, { name: "Rruga e Durrësit", done: false },
  ]},
  { id: "r3", code: "R-15", truck: "AA-106-EC", driver: drivers[2], zones: [ZONES[5], ZONES[6]], bins: 28, distance: 26.7, duration: 130, status: "delayed", progress: 35, stops: [
    { name: "Kombinat Hyrje", done: true }, { name: "Tufinë Pikë 1", done: false }, { name: "Tufinë Pikë 2", done: false },
  ]},
  { id: "r4", code: "R-03", truck: "AA-101-AL", driver: drivers[3], zones: [ZONES[1]], bins: 19, distance: 12.3, duration: 70, status: "completed", progress: 100, stops: [
    { name: "Selitë Veri", done: true }, { name: "Selitë Jug", done: true },
  ]},
];

export type ReportStatus = "submitted" | "under_review" | "assigned" | "resolved";
export interface CitizenReport {
  id: string;
  citizen: string;
  type: string;
  location: string;
  description: string;
  priority: AlertPriority;
  status: ReportStatus;
  createdAt: string;
  assignedTo?: string;
}

export const REPORTS: CitizenReport[] = [
  { id: "rep1", citizen: "Anila K.", type: "Overflowing bin", location: "Rruga Myslym Shyri", description: "Bin overflowing onto sidewalk", priority: "high", status: "assigned", createdAt: "2h ago", assignedTo: "Field Op #3" },
  { id: "rep2", citizen: "Florian D.", type: "Damaged bin", location: "Bulevardi Zogu I", description: "Lid completely broken", priority: "medium", status: "under_review", createdAt: "5h ago" },
  { id: "rep3", citizen: "Marsida B.", type: "Illegal dumping", location: "Don Bosko", description: "Construction debris dumped", priority: "critical", status: "submitted", createdAt: "30 min ago" },
  { id: "rep4", citizen: "Elton S.", type: "Missed collection", location: "Laprakë", description: "Not collected for 3 days", priority: "high", status: "resolved", createdAt: "1 d ago", assignedTo: "Field Op #1" },
  { id: "rep5", citizen: "Brunilda T.", type: "Recycling issue", location: "Blloku", description: "Plastic bin contaminated", priority: "low", status: "submitted", createdAt: "6h ago" },
];

export const USERS = [
  { id: "u1", name: "Edvin Rama", email: "e.rama@ecotirana.al", role: "Admin", status: "active" },
  { id: "u2", name: "Dorina Hoxha", email: "d.hoxha@ecotirana.al", role: "Waste Management Manager", status: "active" },
  { id: "u3", name: "Arben Hoxha", email: "a.hoxha@ecotirana.al", role: "Truck Driver", status: "active" },
  { id: "u4", name: "Bledar Kola", email: "b.kola@ecotirana.al", role: "Truck Driver", status: "active" },
  { id: "u5", name: "Mirela Çela", email: "m.cela@ecotirana.al", role: "Field Operator", status: "active" },
  { id: "u6", name: "Anila Kola", email: "anila@gmail.com", role: "Citizen", status: "active" },
  { id: "u7", name: "Ilir Kraja", email: "i.kraja@ecotirana.al", role: "IT System Administrator", status: "active" },
  { id: "u8", name: "Saimir Doçi", email: "s.doci@ecotirana.al", role: "Truck Driver", status: "inactive" },
];

// Charts data
export const wasteCollectedTrend = [
  { day: "Mon", general: 42, recycling: 18, organic: 22 },
  { day: "Tue", general: 51, recycling: 24, organic: 19 },
  { day: "Wed", general: 38, recycling: 21, organic: 25 },
  { day: "Thu", general: 47, recycling: 29, organic: 23 },
  { day: "Fri", general: 55, recycling: 31, organic: 28 },
  { day: "Sat", general: 62, recycling: 34, organic: 30 },
  { day: "Sun", general: 35, recycling: 19, organic: 17 },
];

export const recyclingPerformance = [
  { month: "Jan", rate: 28 }, { month: "Feb", rate: 31 }, { month: "Mar", rate: 34 },
  { month: "Apr", rate: 36 }, { month: "May", rate: 39 }, { month: "Jun", rate: 42 },
  { month: "Jul", rate: 45 }, { month: "Aug", rate: 43 }, { month: "Sep", rate: 47 },
  { month: "Oct", rate: 49 }, { month: "Nov", rate: 52 }, { month: "Dec", rate: 54 },
];

export const wasteDistribution = [
  { name: "General", value: 48 },
  { name: "Recycling", value: 28 },
  { name: "Organic", value: 18 },
  { name: "Glass", value: 6 },
];

export const zoneComparison = ZONES.slice(0, 8).map((z, i) => ({
  zone: z.split(" - ")[1] ?? z,
  collected: 30 + Math.floor(Math.random() * 50),
  recycled: 10 + Math.floor(Math.random() * 30),
}));

export const fleetUsage = [
  { hour: "06:00", trucks: 2 }, { hour: "08:00", trucks: 7 },
  { hour: "10:00", trucks: 9 }, { hour: "12:00", trucks: 6 },
  { hour: "14:00", trucks: 8 }, { hour: "16:00", trucks: 5 },
  { hour: "18:00", trucks: 3 }, { hour: "20:00", trucks: 1 },
];

export const schedule = [
  { id: "s1", day: "Mon", time: "06:00", zone: ZONES[0], truck: "AA-100-TR", driver: drivers[0], status: "completed" },
  { id: "s2", day: "Mon", time: "08:00", zone: ZONES[4], truck: "AA-103-AL", driver: drivers[1], status: "completed" },
  { id: "s3", day: "Mon", time: "10:00", zone: ZONES[2], truck: "AA-106-EC", driver: drivers[2], status: "in_progress" },
  { id: "s4", day: "Tue", time: "06:00", zone: ZONES[1], truck: "AA-101-AL", driver: drivers[3], status: "planned" },
  { id: "s5", day: "Tue", time: "09:00", zone: ZONES[5], truck: "AA-100-TR", driver: drivers[0], status: "planned" },
  { id: "s6", day: "Wed", time: "07:00", zone: ZONES[3], truck: "AA-103-AL", driver: drivers[1], status: "planned" },
  { id: "s7", day: "Wed", time: "11:00", zone: ZONES[6], truck: "AA-106-EC", driver: drivers[2], status: "planned" },
  { id: "s8", day: "Thu", time: "06:00", zone: ZONES[7], truck: "AA-101-AL", driver: drivers[3], status: "planned" },
  { id: "s9", day: "Fri", time: "08:00", zone: ZONES[0], truck: "AA-100-TR", driver: drivers[0], status: "planned" },
  { id: "s10", day: "Sat", time: "07:00", zone: ZONES[4], truck: "AA-103-AL", driver: drivers[1], status: "planned" },
];

export const DAYS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
export const TIME_SLOTS = ["06:00", "08:00", "10:00", "12:00", "14:00", "16:00"];
